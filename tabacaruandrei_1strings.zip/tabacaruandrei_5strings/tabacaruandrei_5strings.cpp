    #include <fstream>
    #include <string.h>
    using namespace std;

    ifstream fin(text.in);
    ofstream fout(text.out);
    int main()
    {
    string c;
    fin>>c;
    char car;
    int m=0;
    fin>>car;
    for(int i=0;i<c.size();i++)
    {
        if(c[i]==car)
            m++;
    }
    fout<<m;
    }
